# Table B using your existing uncertainty files (NPZ v2)

This version adds --uncertainty-dir to the original Table B driver. With that
option it READS saved omega files, rather than generating replacement samples.
It performs positive-weight LP searches and separate original-MIP LP relaxations.
No MIP optimization is performed.

## Setup

Extract the ZIP directly into scdcopf_admm (the submission directory). Replace
the previous apr_sigma_study.py with this v2; the included core and launcher
have the same filenames as the earlier Table B package. Existing output/result
folders and compare_apr_lp_mip.py are not modified.

Expected inputs:

    scdcopf_admm/apr_sigma_study.py
    scdcopf_admm/apr_sigma_core.py
    scdcopf_admm/hpc_run_apr_sigma.sh
    scdcopf_admm/uncertainty/omega_pglib_opf_case300_ieee_sigma0.01_seed19.npz
    scdcopf_admm/uncertainty/omega_pglib_opf_case300_ieee_sigma0.02_seed19.npz
    ... sigma0.03, sigma0.04, sigma0.05 ...
    ../excel_outputs/pglib_opf_case300_ieee.xlsx

Your generator stores omega in PER UNIT. This driver uses:

    demand_pu = original_Excel_Pd/baseMVA + saved_omega_pu.

The NPZ bus IDs are checked and columns reordered to match the case. baseMVA,
seed, sigma, sample count, finite values and zero-demand-bus noise are checked
BEFORE any model solve. There is no second division of omega by baseMVA.
Each demand vector stays fixed throughout its search and reference solve.
Use the same unchanged Excel files that were used to generate the uncertainty;
your generator does not store an input-Excel hash. The study archives/hashes the
actual current Excel, source and uncertainty files for subsequent reproducibility.

## Start with ONE selected case for Table B

A pilot, using the first 10 saved scenarios at each of the five sigma levels:

```bash
sbatch hpc_run_apr_sigma.sh --case pglib_opf_case300_ieee.xlsx --uncertainty-dir uncertainty --seed 19 --samples 10 --penalty-per-mw 1500 --weight-start 150000 --lp-time-limit 300 --relaxation-time-limit 600 --output-dir output_table_B_300_pilot
```

If the pilot completes and the settings/statuses are correct, the full study:

```bash
sbatch hpc_run_apr_sigma.sh --case pglib_opf_case300_ieee.xlsx --uncertainty-dir uncertainty --seed 19 --samples 100 --penalty-per-mw 1500 --weight-start 150000 --lp-time-limit 300 --relaxation-time-limit 600 --output-dir output_table_B_300_full
```

The full study uses 100 scenarios PER sigma level: 500 weight searches and up
to 500 reference LP solves (provably capacity-infeasible scenarios are recorded
without redundant reference solving). Do not run all 12 cases for the initial
selected-case Table B. Other cases may be investigated later with a new output
directory. All scripts/uncertainty files must be copied to HPC if generated locally.

A file containing 100 scenarios can be used for the 10-scenario pilot: exactly
the first 10 rows are used, without changing the source NPZ. The full run uses
all 100. If fewer rows than requested exist, execution stops before solving.

--time-limit options are per optimization solve, not per study. Default Slurm
wall time is 8 hours, which may be insufficient for 500 searches. Override
--time= before the script name according to permitted cluster limits, or resume:

```bash
sbatch hpc_run_apr_sigma.sh --case pglib_opf_case300_ieee.xlsx --uncertainty-dir uncertainty --seed 19 --samples 100 --penalty-per-mw 1500 --weight-start 150000 --lp-time-limit 300 --relaxation-time-limit 600 --output-dir output_table_B_300_full --resume
```

Resume requires identical study settings and file hashes. Finished samples are
retained; a partially completed sample gets a fresh attempt directory. Previous
attempts are preserved. Recorded errors count as finished; inspect those errors
and use a new output directory for a changed protocol. Native crashes cannot be
caught by Python; the completed per-sample results remain available for resume.

The module/conda configuration follows the existing KFUPM HPC script. Run locally
without Slurm by replacing 'sbatch hpc_run_apr_sigma.sh' with
'python apr_sigma_study.py --solver gurobi --threads 8'. Use --solver highs on a
small case without a Gurobi license. Dependencies are in requirements.txt.

## Objective, bound and units

Proposed objective: original generation cost + M_eta*sum(eta_pu) + W*sum(APR slacks).
--penalty-per-mw 1500 is converted ONCE: M_eta=1500*baseMVA, or 150000 on base100.
Do not pass 150000 to --penalty-per-mw. Initial W=150000 is explicit above.

W always remains positive. A passing start is halved until a verified failure;
a failing start is doubled until a pass; the positive interval is then bisected.
Default interval tolerance is 0.001, maximum 40 weight tests and maximum W=1e9.
A time limit/nonoptimal solve is inconclusive, not an APR failure. A candidate
can be retained even when the search hits a limit. No global monotone threshold
or globally minimum weight is certified. If all tested weights pass, a search
can reach its test limit without finding a fail/pass bracket.

The complete original integer formulation is constructed to verify the candidate
and obtain U, without optimizing a MIP. Its binary variables are then made
continuous while retaining their [0,1] bounds, original objective and constraints.
The reference LP solves on the SAME demand sample. If optimal and verified,
its objective is L. Gap=100*(U-L)/abs(U), requiring a verified U and valid L.
This is a bound gap, not a gap to a known MIP optimum. Zero-valued U has no
percentage gap. A materially invalid L>U is rejected and flagged.

Both models use linear generation cost, assumed-zero transformer phase shifts,
gamma=1 by default, all eligible generator outages, and nonislanding line outages.
These assumptions match the bundled earlier comparison formulation. Do not change
settings across scenarios without documenting it. Saved omega mode currently
requires --demand-scale 1, matching your generator's raw Excel baseline.

## Outputs that fill Table B

- table_B.tex: ready LaTeX table (booktabs, graphicx).
- table_B.csv: the five sigma rows, all min/average/max values, feasibility and
  completion percentages; verified-IP and valid-gap counts, finished_samples.
- scenario_results.csv: per-sample U, L, gap, selected W, counts, times and status.
- plots/: box and violin distributions for W, bound gap and runtime (PNG/PDF).
- study_settings.json: parameters, package versions, source/input hashes,
  uncertainty file hashes and sample counts, network/contingency counts.
- input_uncertainty/: archived copies of the original NPZ files, unchanged.
- samples/alpha_*/sample_*/result.json: incremental per-sample results.
- samples/.../attempt_*/demand_sample.csv and .npz: actual used demand/noise.
- samples/.../attempt_*/lp_search/: all W tests, best candidate CSVs, summaries,
  best_lp_solution.npz with the full LP vector and index mappings.
- samples/.../attempt_*/candidate_dispatch.npz: preventive/contingency dispatch,
  response signals and outage indices.
- samples/.../attempt_*/constructed_ip_solution.npz: full verified original-IP
  vector and binary/index mappings for future MIP starts.
- samples/.../attempt_*/reference_lp_result.json and reference_lp_solution.npz:
  reference status and full vector when optimal and verified.
- samples/.../attempt_*/experiment.log, plus error.txt when applicable.

APR-feasible/completed percentages use the planned R as denominator. Selected-W
statistics use candidates verified in the original integer model. Gap statistics
also require valid reference L. LP-test/runtime statistics include all finished
attempted scenarios, including unsuccessful ones. LP-test count excludes the
reference LP solve. Original files are never rewritten by this study driver.

Total LP time includes an equal share of common input/network/uncertainty
preprocessing plus sample preparation, search construction, all W solves,
candidate construction, validation and search checkpoint writing. Reference-model
construction and reference solves are timed separately. Plot/aggregate export,
source archiving, queue waiting and resume initialization are excluded.

Full per-line/state eta diagnostic CSVs are omitted by default to reduce disk
use, while aggregate checks still run. --full-eta-diagnostics enables them.
NPZ solution vectors, source copies, input/settings and sample files should be
retained on HPC for future MIP work; you need not upload all bulk results.

Rebuild tables/plots from finished samples without solving:

```text
python apr_sigma_study.py --output-dir output_table_B_300_full --summarize-only
```

Create a small results ZIP from inside the output directory:

```bash
zip table_B_results.zip table_B.csv table_B.tex scenario_results.csv study_settings.json
```

Upload that ZIP to fill/check the manuscript table. Tables made before all
samples finish show finished_samples<R and are partial, not final results.

## Validation

Locally tested with a small synthetic Excel case using SciPy/HiGHS and saved
NPZ files in your generator's format. Tests verify exact reuse of omega, correct
per-unit conversion, bus-column reordering, row selection and input mismatch
rejection, as well as the prior LP-search/reference-bound/solution exports.
Gurobi native execution was not available locally; use the pilot to verify
execution on your licensed HPC environment. Synthetic numbers are not PGLib
research results. Omitting --uncertainty-dir retains internal generation for
backward compatibility, but would NOT reproduce your saved NPZ samples.
